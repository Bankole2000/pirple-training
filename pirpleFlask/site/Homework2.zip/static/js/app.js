// Show year
document.querySelector('.year').textContent = new Date().getFullYear();
